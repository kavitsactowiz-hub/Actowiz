#Unserstanding the jmespath 

import jmespath

data = {
    "person": {
        "name": "Alice",
        "age": 30,
        "people": [
            {"name": "Alice", "age": 30},
            {"name": "Bob", "age": 20},
            {"name": "Charlie", "age": 35}
        ]
    }
}

result = jmespath.search("[{}]",data)
print(result)